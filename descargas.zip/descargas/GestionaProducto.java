package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import modelo.Producto;

public class GestionaProducto {

    public boolean agregarProducto(Producto p) {
        Conexion c = new Conexion();
        Connection con = null;

        try {
            con = c.getConexion();

            String sql = "INSERT INTO producto (nombre, descripcion, precio) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setInt(3, p.getPrecio());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("Error al agregar producto: " + e.getMessage());
            return false;

        } finally {
            try { if (con != null) con.close(); } catch (Exception ex) { }
        }
    }

    public ArrayList<Producto> listarProductos() {
        ArrayList<Producto> lista = new ArrayList<>();
        Conexion c = new Conexion();
        Connection con = null;

        try {
            con = c.getConexion();

            String sql = "SELECT id, nombre, descripcion, precio FROM producto";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                int precio = rs.getInt("precio");

                Producto p = new Producto(id, nombre, descripcion, precio);
                lista.add(p);
            }

        } catch (Exception e) {
            System.out.println("Error al listar productos: " + e.getMessage());

        } finally {
            try { if (con != null) con.close(); } catch (Exception ex) { }
        }

        return lista;
    }
}
