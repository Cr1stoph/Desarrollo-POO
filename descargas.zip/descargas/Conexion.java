package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase responsable de abrir y cerrar la conexión a la base de datos.
 * 
 * BD: tienda
 * Tabla: producto
 */
public class Conexion {
    
    private Connection con = null;
    
    /**
     * Retorna un objeto Connection listo para usar.
     */
    public Connection getConexion() throws Exception {
        try {
            String user = "root";   // ajusta si usas otro usuario
            String pass = "";       // ajusta si tu MySQL tiene clave
            String url  = "jdbc:mysql://localhost:3306/tienda?useSSL=false&serverTimezone=UTC";
            
            // Cargar el driver de MySQL (versión moderna)
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            
            // Obtener la conexión
            con = DriverManager.getConnection(url, user, pass);
        } catch (SQLException sqle) {
            System.out.println("Error SQL en la conexión: " + sqle.getMessage());
        }
        return con;
    }
    
    
    /**
     * Cierra la conexión si está abierta.
     */
    public void cerrarConexion() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            System.out.println("Problemas al cerrar la conexión");
        }
    }
}
