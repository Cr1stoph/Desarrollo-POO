package objetos_magicos;

public interface BendicionValar {
    double BONO = 0.03;
    
    Boolean aplicarBendicion(); //Si el peso es inferior a 5k y es 
}
