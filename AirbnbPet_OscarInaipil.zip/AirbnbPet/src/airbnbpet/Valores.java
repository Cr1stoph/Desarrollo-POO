
package airbnbpet;


public interface Valores {
    double VALOR_DIA_ALOJAMIENTO= 25000;
    public double valorFinal(int dia);
}
